﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Laptops : System.Web.UI.Page
{
    public void getCategories()
    {
        int i = 0;
        try
        {
            SqlConnection connect = new SqlConnection();
            connect.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["mycon"].ToString();
            SqlCommand command = new SqlCommand();
            command.Connection = connect;
            command.CommandText = "select SubCategoryID,CompanyName from subcategory where CategoryId=2 order by SubcategoryID";
            SqlDataAdapter adp = new SqlDataAdapter(command);
            DataSet ds = new DataSet();
            adp.Fill(ds, "brands");
            if (ds.Tables["brands"].Rows.Count > 0)
            {
                CategoryName.Items.Clear();
                CategoryName.Items.Add("Select");
                for (i = 0; i < ds.Tables["brands"].Rows.Count; i++)
                {
                    CategoryName.Items.Add(ds.Tables["brands"].Rows[i][0].ToString() + " - " + ds.Tables["brands"].Rows[i][1].ToString());
                }
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

    public void getData(string company)
    {
        try
        {
            SqlConnection connect = new SqlConnection();
            connect.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["mycon"].ToString();
            SqlCommand command = new SqlCommand();
            command.Connection = connect;
            command.CommandText = "select Images,features,model,ID from laptops where company'=" + company + "' order by ID desc";
            SqlDataAdapter adp = new SqlDataAdapter(command);
            DataSet ds = new DataSet();
            adp.Fill(ds, "Products");
            if (ds.Tables["Products"].Rows.Count > 0)
            {
                Repeater1.DataSource = ds.Tables["Products"];
                Repeater1.DataBind();
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            getCategories();
        }
    }

    protected void CategoryName_SelectedIndexChanged(object sender, EventArgs e)
    {

        string a = CategoryName.SelectedItem.ToString();
        //int hyphenIndex = a.IndexOf("-");
        //string b = a.Substring(0, hyphenIndex);
        //b = b.Trim();
        //int productID = Convert.ToInt32(b);
        getData(a);
    }
}